import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class AppLayout {
  static Size getSize(BuildContext context) {
    return MediaQuery.of(context).size;
  }

  static double getScreenHeight() {
    return 600;
  }

  static double getScreenWidth() {
    return 300;
  }

  static double getHeight(double pixels) {
    final screenHeight = getScreenHeight();
    return screenHeight / (screenHeight / pixels);
  }

  static double getWidth(double pixels) {
    final screenWidth = getScreenWidth();
    return screenWidth / (screenWidth / pixels);
  }
}
